<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class SeatBookedMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    // public $seat;

    public $booking;
    public $event;
    public $link;

    public function __construct($booking, $event, $link)
    {
        $this->booking = $booking;
        $this->event = $event;
        $this->link = $link;
    }


    public function build()
    {
        return $this->subject('Invitation: From P23 Africa x Event - ' . $this->event->title)
            ->view('emails.seat-booked')
            ->with([
                'booking' => $this->booking,
                'event' => $this->event,
                'link' => $this->link,
            ]);
    }
    
    /**
     * Get the message envelope.
     */
    // public function envelope(): Envelope
    // {
    //     return new Envelope(
    //         subject: 'Seat Booked Mail',
    //     );
    // }

    /**
     * Get the message content definition.
     */
    // public function content(): Content
    // {
    //     return new Content(
    //         view: 'view.name',
    //     );
    // }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
