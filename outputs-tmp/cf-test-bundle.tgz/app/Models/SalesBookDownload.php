<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SalesBookDownload extends Model
{
    protected $fillable = [
        'name',
        'email',
        'company',
        'phone',
        'email_sent_at',
    ];

    protected $casts = [
        'email_sent_at' => 'datetime',
    ];

    /**
     * Get the route key for the model.
     */
    public function getRouteKeyName()
    {
        return 'id';
    }
}
