<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUser extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'Admin',
            'email' => 'admin@mail.com',
            'password' => Hash::make('password123'), // Important!
            'is_admin' => true,
        ]);

        User::create([
            'name' => 'Staff',
            'email' => 'danijunurdeen@gmail.com',
            'password' => Hash::make('password123'), // Important!
            'is_admin' => true,
        ]);
    }
}
