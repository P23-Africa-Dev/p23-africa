<?php

use App\Http\Middleware\CheckSuspended;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        channels: __DIR__ . '/../routes/channels.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        if (getenv('VERCEL') || getenv('VERCEL_ENV')) {
            $middleware->trustProxies(at: '*');
        }

        $middleware->encryptCookies(except: [
            'locale_choice',
            'locale_prompt',
        ]);

        $middleware->web(append: [
            \App\Http\Middleware\VerifyCsrfToken::class,
        ]);

        $middleware->alias([
            'role' => \Spatie\Permission\Middleware\RoleMiddleware::class,
            'permission' => \Spatie\Permission\Middleware\PermissionMiddleware::class,
            'role_or_permission' => \Spatie\Permission\Middleware\RoleOrPermissionMiddleware::class,

            'check.suspended' => \App\Http\Middleware\CheckSuspended::class,
            'resolve.org' => \App\Http\Middleware\ResolveOrganization::class,
            'legacy.analytics' => \App\Http\Middleware\EnsureLegacyAnalyticsAccess::class,
            'legacy.whatsapp' => \App\Http\Middleware\EnsureLegacyWhatsAppAccess::class,
            'locale' => \App\Http\Middleware\SetLocale::class,
            'browser-locale' => \App\Http\Middleware\RedirectBrowserLocale::class,
        ]);

        // $middleware->append(CheckSuspended::class);

        $middleware->use([
            \App\Http\Middleware\CheckSuspended::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        // Handle 403 errors with custom page regardless of debug mode
        $exceptions->render(function (\Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException $e, $request) {
            return response()->view('errors.403', [], 403);
        });

        // Handle generic HTTP 403 errors
        $exceptions->render(function (\Symfony\Component\HttpKernel\Exception\HttpException $e, $request) {
            if ($e->getStatusCode() === 403) {
                return response()->view('errors.403', [], 403);
            }
        });

        $exceptions->render(function (\Throwable $e, $request) {
            if ($e instanceof \Illuminate\Validation\ValidationException
                || $e instanceof \Illuminate\Auth\AuthenticationException) {
                return null;
            }

            $status = 500;
            if ($e instanceof \Symfony\Component\HttpKernel\Exception\HttpExceptionInterface) {
                $status = $e->getStatusCode();
                if ($status < 500) {
                    return null;
                }
            }

            app(\App\Support\SiteErrorRecorder::class)->record($e, $request, $status);

            if ($request->expectsJson() || $request->is('api/*')) {
                return response()->json([
                    'message' => 'Something went wrong. Please try again in a few minutes.',
                ], $status);
            }

            return response()->view('errors.unavailable', [], $status);
        });
    })->create();
